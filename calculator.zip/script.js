const display = document.getElementById("display");
const buttons = document.querySelectorAll("button");

let expression = "";

/* 🔷 Button Clicks */
buttons.forEach(button => {
  button.addEventListener("click", () => {
    const value = button.textContent;

    if (value === "C") {
      expression = "";
      display.value = "";
    } 
    else if (value === "=") {
      try {
        expression = eval(expression).toString();
        display.value = expression;
      } catch {
        display.value = "Error";
        expression = "";
      }
    } 
    else {
      expression += value;
      display.value = expression;
    }
  });
});

/* 🔷 Keyboard Support */
document.addEventListener("keydown", (e) => {
  const key = e.key;

  if (!isNaN(key) || ["+", "-", "*", "/"].includes(key)) {
    expression += key;
    display.value = expression;
  } 
  else if (key === "Enter") {
    try {
      expression = eval(expression).toString();
      display.value = expression;
    } catch {
      display.value = "Error";
      expression = "";
    }
  } 
  else if (key === "Backspace") {
    expression = expression.slice(0, -1);
    display.value = expression;
  } 
  else if (key === "Escape") {
    expression = "";
    display.value = "";
  }
});